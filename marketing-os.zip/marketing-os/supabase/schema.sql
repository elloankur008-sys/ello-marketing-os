-- ==============================================================================
-- Ellocent Marketing OS — PostgreSQL Schema, Row-Level Security & Realtime
-- Run this once inside your Supabase SQL Editor
-- ==============================================================================

create extension if not exists "pgcrypto";

-- 1. Workspaces (Tenants / Client Projects)
create table if not exists public.workspaces (
  id text primary key,
  name text not null,
  domain text not null,
  currency text not null default 'USD',
  timezone text not null default 'Asia/Kolkata',
  retainer_status text not null default 'Active — Client Project',
  monthly_retainer numeric(12,2) not null default 0,
  ai_spent_usd numeric(10,4) not null default 0,
  ai_budget_usd numeric(10,2) not null default 100,
  created_at timestamptz not null default now()
);

-- 2. Workspace Memberships (Maps Supabase Auth Users to Workspaces & Roles)
create table if not exists public.workspace_memberships (
  id uuid primary key default gen_random_uuid(),
  workspace_id text not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'Client Reviewer',
  created_at timestamptz not null default now(),
  unique(workspace_id, user_id)
);

-- 3. Brand Profiles & Deterministic Policy Guardrails
create table if not exists public.brand_profiles (
  workspace_id text primary key references public.workspaces(id) on delete cascade,
  version text not null default 'v1.0',
  brand_name text not null,
  tagline text not null default '',
  voice_tone text not null default '',
  target_audience text not null default '',
  banned_claims jsonb not null default '[]'::jsonb,
  required_disclaimers jsonb not null default '{"email":"","whatsapp":"","paid":""}'::jsonb,
  updated_at timestamptz not null default now()
);

-- 4. Campaigns & 10-Point Pre-Flight Gatekeeper
create table if not exists public.campaigns (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  name text not null,
  objective text not null,
  channel text not null default 'Multi-Channel',
  status text not null default 'Pre-Flight',
  budget_cap numeric(12,2) not null default 0,
  spent numeric(12,2) not null default 0,
  owner text not null default '',
  start_date text not null default '',
  end_date text not null default '',
  checklist jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

-- 5. Content Assets (SHA-256 Version-Locked)
create table if not exists public.content_assets (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  title text not null,
  channel text not null,
  status text not null default 'Pending Approval',
  version integer not null default 1,
  scheduled_date text not null default '',
  destination_url text not null default '',
  body text not null default '',
  approved_hash text not null default '',
  updated_at timestamptz not null default now()
);

-- 6. SEO & Lighthouse Audits
create table if not exists public.seo_audits (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  domain text not null,
  strategy text not null default 'MOBILE',
  audited_at timestamptz not null default now(),
  pages_crawled integer not null default 1,
  perf_score integer not null default 0,
  seo_score integer not null default 0,
  access_score integer not null default 0,
  lcp text not null default '',
  cls text not null default '',
  findings jsonb not null default '[]'::jsonb
);

-- 7. Paid Media Campaigns & Governed Budget Diffs
create table if not exists public.paid_campaigns (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  platform text not null,
  name text not null,
  status text not null default 'Active',
  daily_budget numeric(12,2) not null default 0,
  spend numeric(12,2) not null default 0,
  conversions integer not null default 0,
  external_campaign_id text,
  updated_at timestamptz not null default now()
);

create table if not exists public.budget_diffs (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  campaign_id text not null references public.paid_campaigns(id) on delete cascade,
  campaign_name text not null,
  current_value numeric(12,2) not null,
  proposed_value numeric(12,2) not null,
  rationale text not null,
  rollback_plan text not null,
  proposed_by text not null,
  status text not null default 'Pending Approval',
  created_at timestamptz not null default now()
);

-- 8. Leads / CRM with Mandatory Consent Provenance
create table if not exists public.leads (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  name text not null,
  company text not null default '',
  email text not null,
  stage text not null default 'New',
  email_opt_in boolean not null default false,
  whatsapp_opt_in boolean not null default false,
  suppressed boolean not null default false,
  consent_source text not null,
  external_event_id text unique,
  created_at timestamptz not null default now()
);

-- 9. Competitor Intelligence & Automations
create table if not exists public.competitors (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  name text not null,
  positioning text not null,
  opportunity_gap text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.automations (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  name text not null,
  trigger_cond text not null,
  actions text not null,
  runs_count integer not null default 0,
  created_at timestamptz not null default now()
);

-- 10. Append-Only Tamper-Evident Audit Ledger
create table if not exists public.audit_events (
  id text primary key,
  workspace_id text not null references public.workspaces(id) on delete cascade,
  timestamp timestamptz not null default now(),
  actor text not null,
  action text not null,
  target text not null,
  correlation_id text not null
);

-- Prevent UPDATE or DELETE on audit_events
create or replace function public.prevent_audit_mutation()
returns trigger language plpgsql as $$
begin
  raise exception 'audit_events is strictly append-only';
end;
$$;

drop trigger if exists trg_audit_no_update on public.audit_events;
create trigger trg_audit_no_update before update or delete on public.audit_events
for each row execute function public.prevent_audit_mutation();

-- ==============================================================================
-- Row-Level Security (Strict Multi-Tenant Isolation)
-- ==============================================================================
alter table public.workspaces enable row level security;
alter table public.workspace_memberships enable row level security;
alter table public.brand_profiles enable row level security;
alter table public.campaigns enable row level security;
alter table public.content_assets enable row level security;
alter table public.seo_audits enable row level security;
alter table public.paid_campaigns enable row level security;
alter table public.budget_diffs enable row level security;
alter table public.leads enable row level security;
alter table public.competitors enable row level security;
alter table public.automations enable row level security;
alter table public.audit_events enable row level security;

create or replace function public.is_workspace_member(ws_id text)
returns boolean language sql security definer stable as $$
  select exists (
    select 1 from public.workspace_memberships
    where workspace_id = ws_id and user_id = auth.uid()
  );
$$;

create policy "members_read_workspaces" on public.workspaces
  for select using (public.is_workspace_member(id));

create policy "authenticated_create_workspaces" on public.workspaces
  for insert with check (auth.uid() is not null);

create policy "members_manage_workspaces" on public.workspaces
  for update using (public.is_workspace_member(id));

create policy "users_read_own_memberships" on public.workspace_memberships
  for select using (user_id = auth.uid());

create policy "users_insert_own_membership" on public.workspace_memberships
  for insert with check (user_id = auth.uid());

create policy "tenant_isolation_brand" on public.brand_profiles
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_isolation_campaigns" on public.campaigns
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_isolation_content" on public.content_assets
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_isolation_seo" on public.seo_audits
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_isolation_paid" on public.paid_campaigns
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_isolation_diffs" on public.budget_diffs
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_isolation_leads" on public.leads
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_isolation_competitors" on public.competitors
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_isolation_automations" on public.automations
  for all using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create policy "tenant_select_audit" on public.audit_events
  for select using (public.is_workspace_member(workspace_id));

create policy "tenant_insert_audit" on public.audit_events
  for insert with check (public.is_workspace_member(workspace_id));

-- Enable Supabase Realtime publications
alter publication supabase_realtime add table
  public.workspaces,
  public.campaigns,
  public.content_assets,
  public.seo_audits,
  public.paid_campaigns,
  public.budget_diffs,
  public.leads,
  public.audit_events;

-- Seed default internal workspace
insert into public.workspaces (id, name, domain, currency, timezone, retainer_status, ai_budget_usd)
values ('ws_ellocent', 'Ellocent Labs — Internal', 'ellocentlabs.com', 'USD', 'Asia/Kolkata', 'Active — Internal Ops', 150.00)
on conflict (id) do nothing;
